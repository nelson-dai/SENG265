#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "Name" account_info.csv contact_info.csv personal_info.csv

