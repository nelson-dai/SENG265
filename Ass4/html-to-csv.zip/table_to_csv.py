import re

def findWithTab(tag, s):
    """
    :param tag: tag name
    :param s: string
    :return: a list of string inside the tag
    """

    pattern =  '<{0}.*?>(.*?)</{0}.*?>'.format(tag)

    return re.findall(pattern, s, re.IGNORECASE|re.DOTALL)

def convertToCSV(s):

    """
    convert html string s to csv
    :param s: string
    :return:
    """

    # tables = re.findall('<table.*?>(.*?)</table>', s, re.IGNORECASE|re.DOTALL)

    # extract table content
    tables = findWithTab('table', s)

    for i, table in enumerate(tables):

        if i > 0:
            print()

        print('TABLE {}:'.format(i+1))

        # extract all rows of table
        rows = findWithTab('tr', table)

        rcs = []

        for row in rows:
            # extract cells in a row
            cells = findWithTab('td', row) + findWithTab('th', row)

            # convert multiple to space characters to 1 space
            for i in range(len(cells)):

                cells[i] = ' '.join(cells[i].split())

            rcs.append(cells)


        maxlen = max([len(cell) for cell in rcs])

        # add empty column if not every row of the table has the same number of columns
        for r in rcs:

            for k in range(len(r), maxlen):

                r.append('')

            # output the csv row
            print(','.join(r))

if __name__ == '__main__':

    import sys
    f = sys.stdin
    # read from input
    s = ''.join(f.readlines())
    # conver to csv
    convertToCSV(s)








